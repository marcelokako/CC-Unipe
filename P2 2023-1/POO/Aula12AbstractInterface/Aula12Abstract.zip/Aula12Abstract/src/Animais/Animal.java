package Animais;

public abstract class Animal {

	
	public void dormir() {
		System.out.println("zzzZZZzzZZzzzZZz");
	}
	
	public abstract void emitirSom();
}
