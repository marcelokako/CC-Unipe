package Animais;

public interface IComportamentos {

}
