package Animais;

public class Gato extends Animal {

	@Override
	public void emitirSom() {
		// TODO Auto-generated method stub
		System.out.println("Miau");
	}

}
