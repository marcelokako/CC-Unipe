package Animais;

public class Cachorro extends Animal{

	@Override
	public void emitirSom() {
		// TODO Auto-generated method stub
		System.out.println("Au au");
	}

	
}
