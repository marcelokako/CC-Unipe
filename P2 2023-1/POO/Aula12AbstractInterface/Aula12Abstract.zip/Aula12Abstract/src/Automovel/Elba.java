package Automovel;

public class Elba extends Automovel {

	@Override
	public void ligar() {
		// TODO Auto-generated method stub
		System.out.println("Ligando Elba");
	}
	
	public void acenderFarol() {
		System.out.println("Farol Ligado");
	}

}
