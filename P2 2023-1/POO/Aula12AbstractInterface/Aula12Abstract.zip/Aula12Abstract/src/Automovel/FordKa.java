package Automovel;

public class FordKa extends Automovel{

	@Override
	public void ligar() {
		// TODO Auto-generated method stub
		System.out.println("Ligando Ford Ka");
	}

}
