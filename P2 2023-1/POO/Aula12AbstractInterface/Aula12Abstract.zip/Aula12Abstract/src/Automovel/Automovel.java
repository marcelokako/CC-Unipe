package Automovel;

public abstract class Automovel {

	private String cor;
	
	public Automovel() {}
	
	public Automovel(String cor) {
		super();
		this.cor = cor;
	}

	public abstract void ligar();

	public String getCor() {
		return cor;
	}


	public void setCor(String cor) {
		this.cor = cor;
	}
}
