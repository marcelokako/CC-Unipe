package Automovel;

public class Jetta extends Automovel {

	@Override
	public void ligar() {
		// TODO Auto-generated method stub
		System.out.println("Ligando Jetta");
	}

}
